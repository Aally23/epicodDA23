CREATE TABLE Volo (
    id_volo INT PRIMARY KEY,
    compagnia_aerea varchar(100),
    partenza varchar(100),
    destinazione varchar(100),
    data_Partenza DATE,
    posti_Disponibili INT,
    prezzo DECIMAL(10,2)
);

CREATE TABLE Hotel (
    id_hotel INT PRIMARY KEY,
    nome varchar(100),
    indirizzo varchar(100),
    citta varchar(100),
    stelle INT,
    disponibilita_camere INT,
    prezzo_camera_EUR DECIMAL(10,2)
);

CREATE TABLE Cliente (
    id_cliente INT PRIMARY KEY,
    nome varchar(100),
    cognome varchar(100),
    email varchar(100),
    numero_telefono varchar(15)
);

CREATE TABLE Prenotazione (
    id_prenotazione INT PRIMARY KEY,
    id_volo INT,
    id_hotel INT,
    id_cliente INT,
    data_prenotazione DATE,
    data_arrivo DATE,
    durata_soggiorno INT,
    costo_tot_EUR DECIMAL(10,2),
    FOREIGN KEY (id_volo) REFERENCES Volo(id_volo),
    FOREIGN KEY (id_hotel) REFERENCES Hotel(id_hotel),
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente)
);

CREATE TABLE Aeroporto (
    codice_iata varchar(3) PRIMARY KEY,
    nome varchar(100),
    citta varchar(100),
    paese varchar(100)
);

CREATE TABLE Recensione (
    id_recensione INT PRIMARY KEY,
    id_cliente INT,
    id_hotel INT,
    id_prenotazione INT,
    valutazione INT,
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente),
    FOREIGN KEY (id_hotel) REFERENCES Hotel(id_hotel),
    FOREIGN KEY (id_prenotazione) REFERENCES Prenotazione(id_prenotazione)
);

INSERT INTO Aeroporto (codice_iata, nome, citta, paese)
VALUES
    ('FCO', 'Aeroporto Internazionale di Roma–Fiumicino Leonardo da Vinci', 'Roma', 'Italia'),
    ('PEK', 'Aeroporto di Pechino-Capitale', 'Pechino', 'Cina'),
	('JFK', 'Aeroporto Internazionale John F. Kennedy', 'New York', 'USA'),
    ('LHR', 'Aeroporto di Londra-Heathrow', 'Londra', 'Regno Unito'),
    ('CDG', 'Aeroporto di Parigi Charles de Gaulle', 'Parigi', 'Francia');
    
INSERT INTO Volo (id_volo, compagnia_aerea, partenza, destinazione, data_Partenza, posti_Disponibili, prezzo)
VALUES
    (1, 'Alitalia', 'Roma', 'New York', '2023-09-15', 150, 800.00),
    (2, 'Delta Airlines', 'New York', 'Londra', '2023-09-30', 120, 900.00),
    (3, 'British Airways', 'Londra', 'Roma', '2023-12-10', 100, 200.00),
    (4, 'Air France', 'Parigi', 'New York', '2023-11-04', 70, 750.00),
    (5, 'Air China', 'New York', 'Pechino', '2023-09-28', 96, 1100.00),
    (6, 'Air France', 'Parigi', 'Pechino', '2023-12-21', 34, 850.00),
    (7, 'Lufthansa', 'New York', 'Roma', '2023-10-20', 67, 600.00),
    (8, 'Air France', 'Parigi', 'Londra', '2023-10-20', 87, 275.00),
    (9, 'Delta Airlines', 'New York', 'Parigi', '2023-11-27', 21, 800.00);

INSERT INTO Hotel (id_hotel, nome, indirizzo, citta, stelle, disponibilita_camere, prezzo_camera_EUR)
VALUES
    (1, 'Grand Hotel Excelsior', 'Via Veneto 123', 'Roma', 5, 50, 200.00),
	(2, 'NH Collection Roma Fori Imperiali', 'Via di Santa Eufemia 19', 'Roma', 5, 60, 945.00),
    (3, '45 Times Square Hotel', '125 West 45th Street', 'New York', 3, 100, 350.00),
    (4, 'Pod Times Square', '400 West 42nd Street, Midtown West', 'New York', 4, 90, 450.00),
    (5, 'Earls Court Garden Hotel', '36 Earls Court Gardens', 'Londra', 2, 50, 99.00),
    (6, 'Knightsbridge Diamond by Dena Elite Collection', '9 Montpelier Street', 'Londra', 5, 30, 890.00),
    (7, 'Hotel Este', '76 Boulevard de Strasbourg', 'Parigi', 4, 92, 420.00),
    (8, 'Hotel Meslay Republique', '3 rue Meslay', 'Parigi', 3, 33, 140.00),
    (9, 'The Great Wall Hotel Beijing', 'No.10 East 3rd ring north road', 'Pechino', 5, 50, 200.00),
    (10, 'Happy Dragon Forbidden City Hotel', '29 Ren Min Shi Chang Xi Xiang', 'Pechino', 2, 10, 35.00);

INSERT INTO Cliente (id_cliente, nome, cognome, email, numero_telefono)
VALUES
    (1, 'Mario', 'Rossi', 'mario@email.com', '123-456-7890'),
    (2, 'Luca', 'Bianchi', 'laura@email.com', '987-654-3210'),
    (3, 'Maria', 'Verdi', 'maria@email.com', '567-890-1234'),
    (4, 'Luigi', 'Neri', 'luigi@email.com', '456-789-0123'),
    (5, 'Giovanna', 'Celesti', 'giovanna@email.com', '456-789-0123'),
    (6, 'Anna', 'Azzurri', 'anna@email.com', '456-789-0123'),
    (7, 'Alessio', 'Marroni', 'alessio@email.com', '456-789-0123'),
    (8, 'Sara', 'Gialli', 'sara@email.com', '456-789-0123'),
    (9, 'Alberto', 'Arancioni', 'alberto@email.com', '456-789-0123');
   
INSERT INTO Prenotazione (id_prenotazione, id_volo, id_hotel, id_cliente, data_prenotazione, data_arrivo, durata_soggiorno, costo_tot_EUR)
VALUES
    (1, 1, 3, 1, '2023-08-20', '2023-09-15', 7, 3250.00),
    (2, 2, 5, 2, '2023-08-25', '2023-09-30', 15, 2385.00),
    (3, 3, 2, 3, '2023-07-01', '2023-12-10', 3, 3035.00),
    (4, 4, 3, 4, '2023-06-05', '2023-11-04', 1, 1100.00),
    (5, 6, 10, 6, '2023-07-20', '2023-12-21', 12, 1150.00),
    (6, 5, 9, 7, '2023-08-25', '2023-09-28', 21, 5300.00),
    (7, 8, 6, 5, '2023-04-01', '2023-10-20', 6, 5615.00),
    (8, 9, 7, 9, '2023-06-05', '2023-11-27', 7, 3740.00),
    (9, 7, 1, 8, '2023-08-20', '2023-10-20', 3, 1200.00);
    
INSERT INTO Recensione (id_recensione, id_cliente, id_hotel, id_prenotazione, valutazione)
VALUES
    (1, 1, 1, 1, 4),
    (2, 2, 2, 2, 5),
    (3, 3, 3, 3, 5),
    (4, 4, 4, 4, 1),
    (5, 1, 1, 5, 2),
    (6, 2, 2, 6, 3),
    (7, 3, 3, 7, 5),
    (8, 4, 4, 8, 4),
    (9, 4, 4, 9, 2);
    
    
-- INTERROGAZIONI --


-- Ricerca degli hotel a New York con almeno 4 stelle e camere disponibili -- 
SELECT *
FROM Hotel
WHERE citta = 'New York' AND stelle >= 4 AND disponibilita_camere > 0;

-- Calcolo del costo totale delle prenotazioni per ciascun cliente --
SELECT nome, cognome, SUM(costo_tot_EUR) AS costo_totale
FROM Cliente
JOIN Prenotazione ON Cliente.id_cliente = Prenotazione.id_cliente
GROUP BY nome, cognome
ORDER BY costo_totale DESC;

-- Ricerca delle città con una media di valutazione degli hotel superiore a 3 --
SELECT citta
FROM Hotel
JOIN Recensione ON Hotel.id_hotel = Recensione.id_hotel
GROUP BY citta
HAVING AVG(valutazione) > 3;

-- Calcolo della durata media del soggiorno per destinazione dei voli --
SELECT destinazione, AVG(Prenotazione.durata_soggiorno) AS durata_media
FROM Volo
JOIN Prenotazione ON Volo.id_volo = Prenotazione.id_volo
GROUP BY Volo.destinazione
ORDER BY durata_media DESC;

-- Conteggio delle prenotazioni per destinazione dei voli --
SELECT destinazione, COUNT(*) AS numero_prenotazioni
FROM Volo
JOIN Prenotazione ON Volo.id_volo = Prenotazione.id_volo
GROUP BY destinazione
ORDER BY numero_prenotazioni DESC;

-- Calcolo del numero di prenotazioni per mese --
SELECT MONTH(data_prenotazione) AS mese, COUNT(*) AS numero_prenotazioni
FROM Prenotazione
GROUP BY mese;

-- Selezione delle prenotazioni effettuate nel terzo trimestre --
SELECT *
FROM Prenotazione
WHERE QUARTER(data_prenotazione) = 3;

-- Calcolo della durata media del soggiorno per mese di arrivo --
SELECT MONTH(data_arrivo) AS mese, AVG(durata_soggiorno) AS durata_media
FROM Prenotazione
GROUP BY mese;

-- Calcolo della media delle valutazioni degli hotel per città --
SELECT citta, AVG(Recensione.valutazione) AS media_valutazione
FROM Hotel
JOIN Recensione ON Hotel.id_hotel = Recensione.id_hotel
WHERE Hotel.stelle >= 3
GROUP BY citta
ORDER BY media_valutazione desc;

-- Volo con il costo totale più basso per una prenotazione effettuata nel mese di luglio --
SELECT Volo.id_volo, partenza, destinazione, MIN(prezzo) AS costo_piu_basso
FROM Volo
JOIN Prenotazione ON Volo.id_volo = Prenotazione.id_volo
WHERE MONTH(data_prenotazione) = 7
GROUP BY id_volo, partenza, destinazione
